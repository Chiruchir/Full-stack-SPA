from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl
from typing import List, Optional
import requests
from bs4 import BeautifulSoup
import nltk
from sentence_transformers import SentenceTransformer
import numpy as np
from weaviate import Client
import os
from dotenv import load_dotenv
import logging
import uvicorn
from datetime import datetime,timezone
# Load environment variables
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Download required NLTK data
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('stopwords')

app = FastAPI(title="Smarter.Codes Search API",
             description="API for searching website content using semantic search",
             version="1.0.0")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
model = SentenceTransformer('all-MiniLM-L6-v2')

# Initialize Weaviate client
WEAVIATE_URL = os.getenv('WEAVIATE_URL', 'http://localhost:8080')
client = Client(url=WEAVIATE_URL)

class SearchRequest(BaseModel):
    url: HttpUrl
    query: str
    max_results: Optional[int] = 10

class SearchResult(BaseModel):
    content: str
    score: float
    position: int

class SearchResponse(BaseModel):
    results: List[SearchResult]
    total_chunks: int
    query_time: float

def setup_schema():
    schema = {
        "classes": [{
            "class": "HTMLChunk",
            "description": "A chunk of HTML content",
            "vectorizer": "none",
            "properties": [
                {
                    "name": "content",
                    "dataType": ["text"],
                    "description": "The text content of the HTML chunk",
                },
                {
                    "name": "url",
                    "dataType": ["string"],
                    "description": "The source URL of the content",
                },
                {
                    "name": "timestamp",
                    "dataType": ["date"],
                    "description": "When this chunk was indexed",
                }
            ]
        }]
    }
    
    try:
        client.schema.create(schema)
        logger.info("Schema created successfully")
    except Exception as e:
        logger.warning(f"Schema creation warning: {e}")

def clean_text(text: str) -> str:
    text = ' '.join(text.split())
    # Remove very short lines
    lines = [line for line in text.splitlines() if len(line.strip()) > 10]
    return '\n'.join(lines)

def chunk_text(text: str, max_tokens: int = 500) -> List[str]:
    sentences = nltk.sent_tokenize(text)
    chunks = []
    current_chunk = []
    current_length = 0
    
    for sentence in sentences:
        sentence_tokens = len(nltk.word_tokenize(sentence))
        if current_length + sentence_tokens > max_tokens:
            if current_chunk:
                chunks.append(' '.join(current_chunk))
            current_chunk = [sentence]
            current_length = sentence_tokens
        else:
            current_chunk.append(sentence)
            current_length += sentence_tokens
    
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    
    return chunks

@app.on_event("startup")
async def startup_event():
    """Run startup tasks."""
    setup_schema()

@app.post("/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    try:
        start_time = datetime.now()
        
        # Fetch HTML content
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        response = requests.get(str(request.url), headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        for element in soup(['script', 'style', 'nav', 'footer', 'iframe']):
            element.decompose()
        text = soup.get_text()
        text = clean_text(text)
        text_chunks = chunk_text(text)
        client.batch.delete_objects(
            class_name="HTMLChunk",
            where={
                "path": ["url"],
                "operator": "Equal",
                "valueString": str(request.url)
            }
        )
        # Index chunks in Weaviate
        with client.batch as batch:
            for chunk in text_chunks:
                # Generate embedding
                embedding = model.encode(chunk)
                current_time=datetime.now(timezone.utc).isoformat()
                # Add to Weaviate
                batch.add_data_object(
                    data_object={
                        "content": chunk,
                        "url": str(request.url),
                        "timestamp": current_time
                    },
                    class_name="HTMLChunk",
                    vector=embedding.tolist()
                )
        # Generate query embedding
        query_embedding = model.encode(request.query)
        response = (
            client.query
            .get("HTMLChunk", ["content"])
            .with_near_vector({
                "vector": query_embedding.tolist()
            })
            .with_limit(request.max_results)
            .with_additional(["distance"])
            .do()
        )
        
        # Extract and format results
        results = []
        for idx, obj in enumerate(response["data"]["Get"]["HTMLChunk"]):
            distance = obj["_additional"]["distance"]
            similarity_score = 1 - (distance / 2)
            results.append(SearchResult(
                content=obj["content"],
                score=similarity_score,
                position=idx + 1
            ))
        query_time = (datetime.now() - start_time).total_seconds()
        
        return SearchResponse(
            results=results,
            total_chunks=len(text_chunks),
            query_time=query_time
        )
    except requests.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Error fetching URL: {str(e)}")
    except Exception as e:
        logger.error(f"Search error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5000)