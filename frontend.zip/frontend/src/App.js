import React, { useState } from 'react';
import axios from 'axios';
import SearchForm from './components/SearchForm';
import ResultList from './components/ResultList';

function App() {
  const [url, setUrl] = useState('');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [queryTime, setQueryTime] = useState(0);
  const [totalChunks, setTotalChunks] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResults([]);

    try {
      const response = await axios.post('http://localhost:5000/search', {
        url,
        query,
        max_results: 10
      });
      
      setResults(response.data.results);
      setQueryTime(response.data.query_time);
      setTotalChunks(response.data.total_chunks);
    } catch (err) {
      setError(err.response?.data?.detail || 'An error occurred while fetching results.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-6 flex flex-col justify-center sm:py-12">
      <div className="relative py-3 sm:max-w-xl sm:mx-auto">
        <div className="relative px-4 py-10 bg-white mx-8 md:mx-0 shadow rounded-3xl sm:p-10">
          <div className="max-w-md mx-auto">
            <div className="divide-y divide-gray-200">
              <div className="py-8 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
                <h1 className="text-2xl font-bold mb-8">Smarter.Codes Search</h1>
                
                <SearchForm 
                  url={url}
                  query={query}
                  setUrl={setUrl}
                  setQuery={setQuery}
                  onSubmit={handleSubmit}
                  loading={loading}
                />

                {error && (
                  <div className="mt-4 p-4 text-red-700 bg-red-100 rounded-md">
                    {error}</div>
                )}

                <ResultList 
                  results={results}
                  queryTime={queryTime}
                  totalChunks={totalChunks}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;