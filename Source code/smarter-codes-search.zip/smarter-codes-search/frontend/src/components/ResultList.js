import React from 'react';

const ResultList = ({ results, queryTime, totalChunks }) => {
  if (!results.length) return null;

  const createMarkup = (html) => {
    return { __html: html };
  };

  return (
    <div className="pt-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Search Results</h2>
        <div className="text-sm text-gray-500">
          Found in {queryTime.toFixed(2)}s ({totalChunks} chunks analyzed)
        </div>
      </div>
      <div className="space-y-4">
        {results.map((result) => (
          <div
            key={result.position}
            className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-2 mb-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-indigo-600 text-white text-sm">
                {result.position}
              </span>
              <span className="text-sm text-gray-500">
                Match Score: {(result.score * 100).toFixed(1)}%
              </span>
            </div>
            <div 
              className="prose max-w-none"
              dangerouslySetInnerHTML={createMarkup(result.content)} 
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResultList;